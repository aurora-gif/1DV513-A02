
package DB;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class DBConnection {

    private static DBConnection instance;
    private static Connection con;
    private Statement statement;

    private DBConnection(String db_name, String username, String password) throws SQLException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.con = DriverManager.getConnection("jdbc:mysql://localhost:3307/" + db_name, username, password);
            this.statement = con.createStatement();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static DBConnection connect(String db_name, String username, String password) throws SQLException {

        if (instance == null) {

            instance = new DBConnection(db_name, username, password);
        }

        return instance;
    }

    public ResultSet execute_query(String query) {

        ResultSet result = null;
        try {
            result = this.con.createStatement().executeQuery(query);
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 942) {
                JOptionPane.showMessageDialog(null, "You are not permitted to do this!");
            }
        }

        return result;
    }

    public int execute_update(String query) {
        try {
            this.statement.executeUpdate(query);
        } catch (SQLException ex) {
            ex.printStackTrace();
            int error = ex.getErrorCode();
            if (error == 942) {
                JOptionPane.showMessageDialog(null, "You are not permitted to do this!");
            }
            return error;
        }
        return -1;

    }

    public static Connection getConnectionObj() {
        // check if null
        if(con == null)
            JOptionPane.showMessageDialog(null, "there is no connection with the database!");
        return con;
    }

    public void disconnect() {
        try {
            this.con.close();
        } catch (SQLException ex) {
            Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
