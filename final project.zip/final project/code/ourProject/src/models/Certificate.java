
package models;


import java.util.Date;


public class Certificate {

    private int certificate_id;
    private String type;
    private String source;
    private String specialization;
    private Date date;
    private Employee employee;

    public Certificate(int certificate_id, String type, String source, String specialization, Date date, Employee emp) {
        this.certificate_id = certificate_id;
        this.type = type;
        this.source = source;
        this.specialization = specialization;
        this.date = date;
        this.employee = emp;
    }

    public Certificate(String type, String source, String specialization, Date date, Employee emp) {
        this.type = type;
        this.source = source;
        this.specialization = specialization;
        this.date = date;
        this.employee = emp;
    }

    public int getCertificate_id() {
        return certificate_id;
    }

    public void setCertificate_id(int certificate_id) {
        this.certificate_id = certificate_id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }


    public Object[] to_row() {

        Object[] row = new Object[]{certificate_id, type, source, specialization, date};
        return row;

    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }
    
    

}
