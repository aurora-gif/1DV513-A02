package models;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;



public class Employee {

    private int employee_id;
    private String first_name;
    private String last_name;
    private String father_name;
    private String mother_name;
    private Date birth_date;
    private Date hire_date;
    private String blood_type;
    private String gender;
    private int salary;
    private Job job;
    private Department department;
    private List<Punishment> punishments = new ArrayList<>();
    private List<Reward> rewards = new ArrayList<>();
    private List<Certificate> certificates = new ArrayList<>();

    public Employee(int employee_id, String first_name, String last_name, String father_name, String mother_name, Date birth_date, Date hire_date, String blood_type, String gender, int salary, Job job, Department department) {
        this.employee_id = employee_id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.father_name = father_name;
        this.mother_name = mother_name;
        this.birth_date = birth_date;
        this.hire_date = hire_date;
        this.blood_type = blood_type;
        this.gender = gender;
        this.salary = salary;
        this.job = job;
        this.department = department;
    }

    public Employee(String first_name, String last_name, String father_name, String mother_name, Date birth_date, Date hire_date, String blood_type, String gender, int salary, Job job, Department department) {
        this.first_name = first_name;
        this.last_name = last_name;
        this.father_name = father_name;
        this.mother_name = mother_name;
        this.birth_date = birth_date;
        this.hire_date = hire_date;
        this.blood_type = blood_type;
        this.gender = gender;
        this.salary = salary;
        this.job = job;
        this.department = department;
    }

    public int getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(int employee_id) {
        this.employee_id = employee_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getFather_name() {
        return father_name;
    }

    public void setFather_name(String father_name) {
        this.father_name = father_name;
    }

    public String getMother_name() {
        return mother_name;
    }

    public void setMother_name(String mother_name) {
        this.mother_name = mother_name;
    }

    public Date getBirth_date() {
        return birth_date;
    }

    public void setBirth_date(Date birth_date) {
        this.birth_date = birth_date;
    }

    public Date getHire_date() {
        return hire_date;
    }

    public void setHire_date(Date hire_date) {
        this.hire_date = hire_date;
    }

    public String getBlood_type() {
        return blood_type;
    }

    public void setBlood_type(String blood_type) {
        this.blood_type = blood_type;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public List<Certificate> getCertificates() {
        return certificates;
    }

    public void setCertificates(List<Certificate> certificates) {
        this.certificates = certificates;
    }

    public List<Punishment> getPunishments() {
        return punishments;
    }

    public void setPunishments(List<Punishment> punishments) {
        this.punishments = punishments;
    }

    public List<Reward> getRewards() {
        return rewards;
    }

    public void setRewards(List<Reward> rewards) {
        this.rewards = rewards;
    }

    public Object[] to_row() {
        Object[] row = {employee_id, first_name, last_name, father_name, mother_name, birth_date, hire_date, blood_type, salary, gender, job, department};
        return row;

    }

    public void addCertificate(Certificate cert) {

        this.certificates.add(cert);
    }

    public void removeCertificate(Certificate cert) {
        for (Certificate c : this.certificates) {
            if (c.getCertificate_id() == cert.getCertificate_id()) {
                this.certificates.remove(c);
                break;
            }
        }

    }

    public void replaceCertificate(Certificate certificate) {
        for (int i = 0; i < this.certificates.size(); i++) {
            Certificate cer = certificates.get(i);
            if (cer.getCertificate_id() == certificate.getCertificate_id()) {
                this.certificates.set(i, certificate);
            }
        }

    }

    public void addPunishment(Punishment punish) {

        this.punishments.add(punish);
    }

    public void removePunishment(Punishment punishment) {
        for (Punishment pun : this.punishments) {
            if (pun.getPunishment_id() == punishment.getPunishment_id()) {
                this.punishments.remove(pun);
                break;
            }
        }

    }

    public void replacePunishment(Punishment punishment) {
        for (int i = 0; i < this.punishments.size(); i++) {
            Punishment pun = punishments.get(i);
            if (pun.getPunishment_id() == punishment.getPunishment_id()) {
                this.punishments.set(i, punishment);
                break;
            }
        }

    }

    public void addReward(Reward reward) {

        this.rewards.add(reward);
    }

    public void removeReward(Reward reward) {
        for (Reward re : this.rewards) {
            if (re.getReward_id() == reward.getReward_id()) {
                this.rewards.remove(re);
                break;
            }
        }

    }

    public void replaceReward(Reward reward) {
        for (int i = 0; i < this.rewards.size(); i++) {
            Reward re = rewards.get(i);
            if (re.getReward_id() == reward.getReward_id()) {
                this.rewards.set(i, reward);
                break;
            }
        }

    }

}
