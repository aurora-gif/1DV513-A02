https://www.youtube.com/watch?v=9v5aP9bXgYE

https://github.com/aurora-gif/1DV513-A03


readme file in github has someinfo about the implementation.